//=======================================================================
// Copyright Baptiste Wicht 2013-2018.
// Distributed under the terms of the MIT License.
// (See accompanying file LICENSE or copy at
//  http://www.opensource.org/licenses/MIT)
//=======================================================================

#ifndef NET_ALPHA_H
#define NET_ALPHA_H

namespace network {

void alpha();

} // end of network namespace

#endif
